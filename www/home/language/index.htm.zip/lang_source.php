<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: lang_source.php 12489 2009-07-01 06:41:34Z xupeng $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

$_SGLOBAL['sourcelang'] = array (

	'hour' => 'hr',
	'before' => ' ago',
	'minute' => ' min',
	'second' => ' sec',
	'now' => ' now',
	'dot' => '. ',
	'mtag' => ' groups',
	'poll' => ' poll',
	'event' => ' event',
	'thread' => ' discussion',
	'blog' => ' blog',
	'friend_group_default' => ' Other',
	'friend_group_1' => 'Online Friend',
	'friend_group_2' => 'Meet in event',
	'friend_group_3' => 'Friends friend',
	'friend_group_4' => 'Relative',
	'friend_group_5' => 'Colleague',
	'friend_group_6' => 'Schoolmate',
	'friend_group_7' => 'Never meet',
	'friend_group' => 'Define',
	'default_albumname' => 'Default Album',
	'wall' => 'Wall',
	'pic_comment' => 'Photo Comment',
	'blog_comment' => 'Blog Comment',
	'clickblog' => 'Blog Rank',
	'clickpic' => 'Photo Rank',
	'clickthread' => 'Topic Rank',
	'share_comment' => 'Share Comment',
	'share_notice' => 'Share',
	'doing_comment' => 'Doing reply',
	'friend_notice' => 'Friends',
	'thread_comment' => 'Topic Comment',
	'event_comment' => 'Event Comment',
	'event_member' => 'Event Attending',
	'event_memberstatus' => 'Member status',
	'poll_comment' => 'Poll Comment',
	'poll_invite' => 'Invited to vote',
	'credit' => 'Credit',
	'credit_unit' => 'Value',
	'man' => 'Male',
	'woman' => 'Female',
	'year' => ' Year',
	'month' => ' Month ',
	'day' => ' Day ',
	'unmarried' => 'Unmarried',
	'married' => 'Married',
	'hidden_username' => 'Anonymous'
);

?>